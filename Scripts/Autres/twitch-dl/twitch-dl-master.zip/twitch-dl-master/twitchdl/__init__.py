__version__ = "2.1.3"

CLIENT_ID = "kd1unb4b3q4t58fwlpcbzcbnm76a8fp"
