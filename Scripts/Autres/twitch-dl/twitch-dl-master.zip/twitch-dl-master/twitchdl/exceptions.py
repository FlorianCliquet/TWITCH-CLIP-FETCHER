
class ConsoleError(Exception):
    """Raised when an error occurs and script exectuion should halt."""
    pass
