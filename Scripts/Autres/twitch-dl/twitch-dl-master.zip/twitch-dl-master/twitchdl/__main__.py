from twitchdl.console import main

main()
